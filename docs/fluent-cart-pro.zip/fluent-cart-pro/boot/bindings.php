<?php

/**
 * Add only the plugin specific bindings here.
 * 
 * $app
 * @var WPFluentMicro\App\Foundation\Application
 */
