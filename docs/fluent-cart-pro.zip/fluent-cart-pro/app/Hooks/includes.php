<?php

/*
 * Require any extra files here. For example::
 * require_once "shortcodes.php";
 * require_once "crontasks.php";
 */

/**
 * @var $app WPFluentMicro\Foundation\Application
 */

