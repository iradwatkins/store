<?php

namespace FluentCartPro\App\Core;

use FluentCartPro\App\Core\AppTrait;

class App
{   
    use AppTrait;
}
