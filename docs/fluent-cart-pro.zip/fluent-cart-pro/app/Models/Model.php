<?php

namespace FluentCartPro\App\Models;

use FluentCart\App\Models\Model as BaseModel;

class Model extends BaseModel
{
    // ...
}
